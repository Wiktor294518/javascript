CREATE PROCEDURE tsql_zad1
@cenaMAX INT,
@cenaMIN int
AS
BEGIN
    SELECT * FROM Produkt
    WHERE cena >= @cenaMIN AND CENA <=@cenaMax;
END;
go

