CREATE PROCEDURE GetRandomEmployee
AS
BEGIN
    -- Deklaracja zmiennych
    DECLARE @EmployeeId INT
    DECLARE @Name NVARCHAR(255)
    DECLARE @Job NVARCHAR(255)
    DECLARE @Manager INT
    DECLARE @HireDate DATETIME
    DECLARE @Salary INT
    DECLARE @Commission INT
    DECLARE @Department INT

    -- Tworzenie SCROLL CURSOR do przeglądania tabeli emp
    DECLARE RandomEmployeeCursor SCROLL CURSOR FOR
    SELECT empno, ename, job, mgr, hiredate, sal, comm, deptno
    FROM emp

    -- Wybieranie losowego wiersza
    SELECT TOP 1 @EmployeeId = empno, @Name = ename, @Job = job, @Manager = mgr, @HireDate = hiredate, @Salary = sal, @Commission = comm, @Department = deptno
    FROM emp
    ORDER BY NEWID()

    -- Zwracanie wyniku
    PRINT  CAST(@EmployeeId AS NVARCHAR(10)) + ' ' + @Name + ' ' + @Job + ' ' + CAST(@Manager AS NVARCHAR(10)) + ' ' + CAST(@HireDate AS NVARCHAR(10)) + ' ' + CAST(@Salary AS NVARCHAR(10))+ ' ' + CAST(@Commission AS NVARCHAR(10)) + ' ' + CAST(@Department AS NVARCHAR(10))

    -- Zamykanie i dealokowanie kursora
    CLOSE RandomEmployeeCursor
    DEALLOCATE RandomEmployeeCursor
END
go

