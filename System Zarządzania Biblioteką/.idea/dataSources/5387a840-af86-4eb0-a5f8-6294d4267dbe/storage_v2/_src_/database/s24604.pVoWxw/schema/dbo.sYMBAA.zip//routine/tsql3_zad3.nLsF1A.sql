CREATE PROCEDURE tsql3_zad3
@id_wydawnictwo INT,
@tytul VARCHAR,
@gatunek VARCHAR
AS BEGIN
	IF NOT EXISTS (SELECT nazwa_gatunku FROM gatunek WHERE nazwa_gatunku=@gatunek)
		INSERT INTO gatunek VALUES (@gatunek)

	INSERT INTO KSIAZKA Values((SELECT MAX(id_ksiazki)+1 FROM KSIAZKA), @TYTUL, @GATUNEK, 1)
END
go

