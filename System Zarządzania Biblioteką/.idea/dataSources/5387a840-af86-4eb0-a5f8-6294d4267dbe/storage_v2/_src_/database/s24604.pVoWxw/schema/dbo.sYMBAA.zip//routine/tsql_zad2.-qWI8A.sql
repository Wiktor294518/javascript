CREATE PROCEDURE tsql_zad2
@nazwa Varchar
AS
BEGIN
    IF not exists (select * from kategoria where kategoria = @nazwa)
	Insert into Kategoria Values((Select MAX(id_kategoria) From Kategoria)+1, @nazwa)
ELSE
PRINT 'PODANA KATEGORIA JUŻ STNIEJE';

END;
go

