CREATE PROCEDURE tsql3
@id_wydawnictwo INT,
@tytul VARCHAR(20),
@gatunek VARCHAR(20)
AS BEGIN
	IF NOT EXISTS (SELECT nazwa_gatunku FROM gatunek WHERE nazwa_gatunku=@gatunek)
		INSERT INTO gatunek VALUES (@gatunek)

	INSERT INTO KSIAZKA Values((SELECT MAX(id_ksiazki) FROM KSIAZKA), @TYTUL, @GATUNEK, 1)
END
go

