--2
Create procedure A1
@imie Varchar(20),
@nazwisko Varchar(20)
AS begin
Declare @Output INT
	Select @Output = count(ID_SPRZEDAZ) From Klient
	Inner Join Sprzedaz on Klient.ID_KlIENT = Sprzedaz.ID_KLIENT
	where imie= @imie and nazwisko = @nazwisko;
	Print @Output
end
go

