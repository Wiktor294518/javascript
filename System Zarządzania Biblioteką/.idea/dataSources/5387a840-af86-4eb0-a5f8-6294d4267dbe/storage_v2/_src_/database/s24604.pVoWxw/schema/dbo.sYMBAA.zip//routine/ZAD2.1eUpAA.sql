CREATE PROCEDURE ZAD2
AS 
BEGIN
    DECLARE @CZYZAPLACONE BIT, @DATA DATE, @IDGOSCA INT, @IDREZERWACJI INT

    DECLARE kursor CURSOR FOR 
    SELECT ZAPLACONA, DATAOD, IdGosc, IdRezerwacja FROM Rezerwacja

    OPEN kursor

    FETCH NEXT FROM kursor INTO @CZYZAPLACONE, @DATA, @IDGOSCA, @IDREZERWACJI

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF (@CZYZAPLACONE = 0 AND @DATA < GETDATE())
        BEGIN
            IF (SELECT COUNT(*) FROM Rezerwacja WHERE IdGosc = @IDGOSCA) = 1
            BEGIN
                DECLARE @ImieNazwisko NVARCHAR(100)
                SELECT @ImieNazwisko = IMIE + ' ' + NAZWISKO FROM GOSC WHERE IdGosc = @IDGOSCA
                DELETE FROM GOSC WHERE IdGosc = @IDGOSCA
                PRINT 'Usunięto gościa: ' + @ImieNazwisko
            END

            DELETE FROM REZERWACJA WHERE IdRezerwacja = @IDREZERWACJI
            PRINT 'Usunięto nieopłaconą rezerwację o ID: ' + CAST(@IDREZERWACJI AS NVARCHAR(10))
        END

        FETCH NEXT FROM kursor INTO @CZYZAPLACONE, @DATA, @IDGOSCA, @IDREZERWACJI
    END

    CLOSE kursor
    DEALLOCATE kursor
END
go

