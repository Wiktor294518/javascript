CREATE PROCEDURE plsql3
@id INT,
@ile INT OUTPUT
AS
 BEGIN
	Select @ile = AVG(ILOSC)  from SPRZEDAZ where ID_PRODUKT = @id;
    if @ile>0 
        PRINT 'SREDNIA ILOSC SPRZEDANEGO PRODUKTU TO: ' + CONVERT(varchar, @ile);
      END





go

