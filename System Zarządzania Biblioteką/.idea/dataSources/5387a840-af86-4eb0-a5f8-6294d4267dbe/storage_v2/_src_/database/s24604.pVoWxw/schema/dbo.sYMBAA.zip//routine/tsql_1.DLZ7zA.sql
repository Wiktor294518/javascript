CREATE PROCEDURE tsql_1
@gatunek varchar
AS BEGIN
	SELECT * FROM ksiazka WHERE nazwa_gatunku = @gatunek

END
go

