CREATE PROCEDURE tsql2_2
@id INT,
@ile INT OUTPUT
AS BEGIN
	Select @ile =Count(*) from wyporzyczenia where id_czytelnika = @id
PRINT 'Czytelnik wyporzyczył: ' + CONVERT(VARCHAR, @ile) + ' ksiazek'
END
go

