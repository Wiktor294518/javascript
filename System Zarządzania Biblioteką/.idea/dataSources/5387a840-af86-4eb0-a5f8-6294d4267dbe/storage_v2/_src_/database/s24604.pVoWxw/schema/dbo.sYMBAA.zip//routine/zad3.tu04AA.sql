--3
CREATE PROCEDURE zad3
@nazwa VARCHAR(20)
AS BEGIN
	IF NOT EXISTS (SELECT id_miasto FROM miasto WHERE miasto = @nazwa)
	begin
		Print 'miasto nie istnieje'
		end
		else
	UPDATE klient SET id_miasto = (SELECT id_miasto FROM miasto WHERE miasto = null) WHERE id_miasto = @nazwa
END
go

