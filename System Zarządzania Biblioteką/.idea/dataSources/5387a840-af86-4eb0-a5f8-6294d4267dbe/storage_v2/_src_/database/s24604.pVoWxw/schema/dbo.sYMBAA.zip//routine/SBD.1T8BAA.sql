
CREATE PROCEDURE SBD
@MIN INT,
@MAX INT
AS BEGIN
	DECLARE kursor CURSOR FOR SELECT ename, sal FROM emp
DECLARE @nazwisko VARCHAR(20), @pensja INT
OPEN kursor
FETCH NEXT FROM kursor INTO @nazwisko, @pensja
WHILE @@FETCH_STATUS = 0
BEGIN
IF @pensja< @MIN
begin
set @pensja = @pensja *1.1
end
IF @pensja> @MAX
begin
set @pensja = @pensja *0.9

end
	PRINT @nazwisko + ' zarabia ' + CONVERT(VARCHAR,@pensja)
	FETCH NEXT FROM kursor INTO @nazwisko, @pensja
END
CLOSE kursor
DEALLOCATE kursor

END
go

