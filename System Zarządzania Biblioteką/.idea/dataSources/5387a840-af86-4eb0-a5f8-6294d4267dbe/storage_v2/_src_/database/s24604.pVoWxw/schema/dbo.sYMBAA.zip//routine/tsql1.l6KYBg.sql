CREATE PROCEDURE tsql1
@gatunek varchar(20)
AS BEGIN
	SELECT * FROM ksiazka WHERE nazwa_gatunku = @gatunek
END
go

