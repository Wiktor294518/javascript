CREATE PROCEDURE tsql2_zad2
@nazwa Varchar
AS
BEGIN
    IF not exists (select * from kategoria where kategoria = @nazwa)
	Insert into Kategoria Values((Select MAX(id_kategoria) From Kategoria)+1, @nazwa)
END;

go

