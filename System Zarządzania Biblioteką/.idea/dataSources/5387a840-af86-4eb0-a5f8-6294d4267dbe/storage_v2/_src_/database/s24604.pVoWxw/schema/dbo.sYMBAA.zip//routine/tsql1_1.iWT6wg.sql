CREATE PROCEDURE tsql1_1
@cena INT
AS
BEGIN
    SELECT * FROM Produkt
    WHERE cena >= @cena;
END;
go

