CREATE TRIGGER tsql_zad4
ON KLIENT
for delete
as
BEGIN
     IF EXISTS (SELECT * from Sprzedaz where ID_KLIENT = (Select ID_KLIENT from deleted))
  	rollback
	PRINT 'nie mozna usunac ';
    END
Delete from KLIENT where ID_KLIENT =1;
go

