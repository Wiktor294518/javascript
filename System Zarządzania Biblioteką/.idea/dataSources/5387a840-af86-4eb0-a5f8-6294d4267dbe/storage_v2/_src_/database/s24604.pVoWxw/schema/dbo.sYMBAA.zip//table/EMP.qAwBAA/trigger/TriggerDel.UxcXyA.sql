Create Trigger TriggerDel
on emp
for delete
as begin
rollback
end
go

