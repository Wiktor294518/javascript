CREATE PROCEDURE tsql2
@nazwa VARCHAR(20)
AS BEGIN
	IF NOT EXISTS (SELECT nazwa_gatunku FROM gatunek WHERE nazwa_gatunku=@nazwa)
		INSERT INTO gatunek VALUES (@nazwa)
END
go

