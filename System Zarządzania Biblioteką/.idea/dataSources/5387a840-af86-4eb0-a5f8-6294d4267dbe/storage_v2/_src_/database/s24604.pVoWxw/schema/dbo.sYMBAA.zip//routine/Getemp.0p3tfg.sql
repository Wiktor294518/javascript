CREATE PROCEDURE Getemp
AS
BEGIN
    DECLARE @EmployeeId INT
    DECLARE @Name NVARCHAR(255)
    DECLARE @Job NVARCHAR(255)
    DECLARE @Manager INT
    DECLARE @HireDate DATETIME
    DECLARE @Salary INT
    DECLARE @Commission INT
    DECLARE @Department INT

    DECLARE RandomEmployeeCursor SCROLL CURSOR FOR
    SELECT empno, ename, job, mgr, hiredate, sal, comm, deptno
    FROM emp

	OPEN RandomEmployeeCursor

    SELECT TOP 1 @EmployeeId = empno, @Name = ename, @Job = job, @Manager = mgr, @HireDate = hiredate, @Salary = sal, @Commission = comm, @Department = deptno
    FROM emp
    ORDER BY NEWID()
    PRINT  CAST(@EmployeeId AS NVARCHAR(10)) + ' ' + @Name + ' ' + @Job + ' ' + CAST(@Manager AS NVARCHAR(10)) + ' ' + CAST(@HireDate AS NVARCHAR(10)) + ' ' + CAST(@Salary AS NVARCHAR(10))+ ' ' + CAST(@Commission AS NVARCHAR(10)) + ' ' + CAST(@Department AS NVARCHAR(10))

    CLOSE RandomEmployeeCursor
    DEALLOCATE RandomEmployeeCursor
END
go

