--1
Create procedure zad1
@produkt varchar(20)
as begin
	declare @suma int
	select @suma = COUNT(*) from SPRZEDAZ where ID_PRODUKT =(select ID_PRODUKT from PRODUKT where NAZWA = @produkt)
end
go

