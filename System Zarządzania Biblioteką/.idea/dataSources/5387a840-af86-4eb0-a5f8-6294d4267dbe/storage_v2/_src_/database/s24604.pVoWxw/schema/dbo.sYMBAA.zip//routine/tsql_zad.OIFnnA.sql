CREATE PROCEDURE tsql_zad
@id INT
AS
 BEGIN
 declare @ile int
	Select @ile = AVG(ILOSC)  from SPRZEDAZ where ID_PRODUKT = @id;
    if @ile>0 
        PRINT 'SREDNIA ILOSC SPRZEDANEGO PRODUKTU TO: ' + CONVERT(varchar, @ile);
      END







go

