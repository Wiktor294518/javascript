CREATE TRIGGER tsql5_zad5
ON MIASTO
for insert
as
BEGIN
  if exists (SELECT * FROM MIASTO where MIASTO =(Select MIASTO from inserted))
	rollback
	PRINT 'duplikat miasta';
END
go

