--3
Create Trigger Triggermod
on emp
for insert, update
as begin
		IF EXISTS (SELECT empno FROM inserted WHERE sal < 1000)
		ROLLBACK
END
go

