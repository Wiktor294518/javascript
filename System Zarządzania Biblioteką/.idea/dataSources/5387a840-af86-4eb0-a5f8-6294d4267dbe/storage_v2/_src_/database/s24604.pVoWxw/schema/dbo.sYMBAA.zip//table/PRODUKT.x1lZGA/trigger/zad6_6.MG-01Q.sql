CREATE TRIGGER zad6_6
ON Produkt
FOR Update
AS 
Declare @cen int
BEGIN
	(Select @CEN = CENA from INSERTED)

iF @CEN<1
	UPDATE PRODUKT SET CENA = 1 WHERE ID_PRODUKT in (SELECT ID_PRODUKT FROM PRACOWNIK WHERE CENA = (SELECT CENA FROM INSERTED))

	IF exists (Select ID_Produkt from inserted where CENA < (Select cena from deleted))
	ROLLBACK
END
go

